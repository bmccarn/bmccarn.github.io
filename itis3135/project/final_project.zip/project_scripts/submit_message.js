function contactUsMessage() {
    let name = document.getElementById("contact_fname").value;
    alert("Thanks for reaching out, " + name + "! " + "We'll be in touch soon.");
}

function newsLetterMessage() {
    alert("You are now subscribed!");
}

function scheduleMessage() {
    alert("Your session is scheduled, see you soon!");
}